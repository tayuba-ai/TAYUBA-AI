import React, { useEffect, useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, SafeAreaView, StatusBar, Alert,
  Image, ActivityIndicator,
  KeyboardAvoidingView, Platform
} from 'react-native';

import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import * as Speech from 'expo-speech';

// ==================================
// SUPABASE CONNECTION
// ==================================

const SUPABASE_URL = 'https://ubzmpniebseomydxxqse.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_W8Iy1XCg_rH9Id-q5QOWbA_TuaZTIoj';

const FUNCTION_NAME = 'tayuba-chat-';

// ==================================
// APP SETTINGS
// ==================================

const BLUE = '#078BFF';
const DARK = '#050B19';

const CHAT_KEY = 'tayuba_chats';
const PROFILE_KEY = 'tayuba_profile';

const newId = () => Date.now().toString() +
  Math.random().toString(36).slice(2);

// ==================================
// MAIN APPLICATION
// ==================================

export default function App() {

  const [tab, setTab] = useState('Home');

  const [message, setMessage] = useState('');

  const [messages, setMessages] = useState([
    {
      id: newId(),
      role: 'ai',
      text: 'Hello! 👋 I am TAYUBA AI. How can I help you today?'
    }
  ]);

  const [history, setHistory] = useState([]);

  const [selectedImage, setSelectedImage] = useState(null);

  const [loading, setLoading] = useState(false);

  const [name, setName] = useState('TAYUBA AI User');

  const [email, setEmail] = useState('');

  const [premium, setPremium] = useState(false);

  const [chatId, setChatId] = useState(newId());

  // ==================================
  // LOAD SAVED DATA
  // ==================================

  useEffect(() => {

    async function loadData() {

      try {

        const savedChats = await AsyncStorage.getItem(CHAT_KEY);

        const savedProfile = await AsyncStorage.getItem(PROFILE_KEY);

        if (savedChats) {
          setHistory(JSON.parse(savedChats));
        }

        if (savedProfile) {

          const p = JSON.parse(savedProfile);

          setName(p.name || 'TAYUBA AI User');

          setEmail(p.email || '');

          setPremium(!!p.premium);

        }

      } catch (e) {
        console.log(e);
      }

    }

    loadData();

  }, []);

  // ==================================
  // SAVE CHAT HISTORY
  // ==================================

  async function saveHistory(list) {

    setHistory(list);

    await AsyncStorage.setItem(
      CHAT_KEY,
      JSON.stringify(list)
    );

  }

  async function saveCurrentChat(list) {

    const first = list.find(x => x.role === 'user');

    const chat = {
      id: chatId,
      title: first?.text?.slice(0, 40) || 'New conversation',
      date: new Date().toISOString(),
      messages: list
    };

    const updated = [
      chat,
      ...history.filter(x => x.id !== chatId)
    ].slice(0, 50);

    await saveHistory(updated);

  }

  // ==================================
  // SUPABASE + GEMINI CONNECTION
  // ==================================

  async function askAI(text, image = null, audio = null) {

    if (
      SUPABASE_URL.includes('YOUR_') ||
      SUPABASE_ANON_KEY.includes('YOUR_')
    ) {
      throw new Error('Please enter your Supabase URL and anon key.');
    }

    const response = await fetch(
      `${SUPABASE_URL.replace(/\/$/, '')}/functions/v1/${FUNCTION_NAME}`,
      {
        method: 'POST',

        headers: {
          'Content-Type': 'application/json',
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        },

        body: JSON.stringify({

          message: text || 'Please examine the attached media.',

          image: image ? {
            data: image.base64,
            mimeType: image.mimeType || 'image/jpeg'
          } : undefined,

          audio: audio ? {
            data: audio.base64,
            mimeType: audio.mimeType || 'audio/mp4'
          } : undefined

        })
      }
    );

    const data = await response.json();

    if (!response.ok) {

      throw new Error(
        data.details?.message ||
        data.error ||
        'AI connection failed'
      );

    }

    return data.reply;

  }

  // ==================================
  // SEND MESSAGE
  // ==================================

  async function sendMessage(override = null, audio = null) {

    const text = (override ?? message).trim();

    if (!text && !selectedImage && !audio) {

      Alert.alert(
        'Empty message',
        'Please enter a message or attach an image.'
      );

      return;

    }

    if (loading) return;

    const image = selectedImage;

    const userMsg = {
      id: newId(),
      role: 'user',
      text: text || (audio ? '🎙 Voice message' : 'Image attached'),
      imageUri: image?.uri || null
    };

    const updated = [...messages, userMsg];

    setMessages(updated);

    setMessage('');

    setSelectedImage(null);

    setLoading(true);

    await saveCurrentChat(updated);

    try {

      const reply = await askAI(text, image, audio);

      const finalMessages = [
        ...updated,
        {
          id: newId(),
          role: 'ai',
          text: reply
        }
      ];

      setMessages(finalMessages);

      await saveCurrentChat(finalMessages);

    } catch (error) {

      const failed = [
        ...updated,
        {
          id: newId(),
          role: 'ai',
          text: 'Connection error: ' + error.message
        }
      ];

      setMessages(failed);

      await saveCurrentChat(failed);

    } finally {

      setLoading(false);

    }

  }

  // ==================================
  // IMAGE ATTACHMENT
  // ==================================

  async function pickImage() {

    try {

      const result = await ImagePicker.launchImageLibraryAsync({

        mediaTypes: ['images'],

        allowsEditing: true,

        quality: 0.7,

        base64: true

      });

      if (!result.canceled && result.assets[0].base64) {

        setSelectedImage({

          uri: result.assets[0].uri,

          base64: result.assets[0].base64,

          mimeType: result.assets[0].mimeType || 'image/jpeg'

        });

      }

    } catch (error) {

      Alert.alert('Image error', error.message);

    }

  }

  // ==================================
  // VOICE RECORDING
  // ==================================

  function voiceMessage() {

    Alert.alert(
      'Voice Recording',
      'Voice recording will be available in the APK version. For now, please type your message or use image.'
    );

  }

  // ==================================
  // NEW CHAT
  // ==================================

  function newChat() {

    setChatId(newId());

    setMessages([
      {
        id: newId(),
        role: 'ai',
        text: 'Hello! 👋 Welcome back to TAYUBA AI.'
      }
    ]);

    setMessage('');

    setSelectedImage(null);

    setTab('Home');

  }

  // ==================================
  // OPEN HISTORY
  // ==================================

  function openHistory(chat) {

    setChatId(chat.id);

    setMessages(chat.messages);

    setTab('Home');

  }

  // ==================================
  // SAVE PROFILE
  // ==================================

  async function saveProfile() {

    await AsyncStorage.setItem(
      PROFILE_KEY,
      JSON.stringify({
        name,
        email,
        premium
      })
    );

    Alert.alert('Success', 'Profile saved successfully.');

  }

  // ==================================
  // CHAT SCREEN
  // ==================================

  function HomeScreen() {

    return (

      <>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ padding: 15 }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >

          {messages.length <= 1 && (

            <View style={{ marginBottom: 20 }}>

              <Text style={styles.welcome}>
                Ask. Learn. Create.
              </Text>

              <Text style={styles.subtitle}>
                What can I help you with today?
              </Text>

            </View>

          )}

          {messages.map(item => (

            <View
              key={item.id}
              style={[
                styles.bubble,
                item.role === 'user'
                  ? styles.userBubble
                  : styles.aiBubble
              ]}
            >

              <Text style={styles.label}>
                {item.role === 'user' ? 'YOU' : 'TAYUBA AI'}
              </Text>

              {item.imageUri && (

                <Image
                  source={{ uri: item.imageUri }}
                  style={styles.chatImage}
                />

              )}

              <Text style={styles.messageText}>
                {item.text}
              </Text>

              {item.role === 'ai' && (

                <TouchableOpacity
                  onPress={() =>
                    Speech.speak(item.text, { language: 'en' })
                  }
                >

                  <Text style={styles.readAloud}>
                    🔊 Read aloud
                  </Text>

                </TouchableOpacity>

              )}

            </View>

          ))}

          {loading && (

            <ActivityIndicator
              size="large"
              color={BLUE}
              style={{ margin: 20 }}
            />

          )}

        </ScrollView>

        {selectedImage && (

          <View style={styles.preview}>

            <Image
              source={{ uri: selectedImage.uri }}
              style={{ width: 45, height: 45 }}
            />

            <Text style={styles.subtitle}>
              Image attached
            </Text>

            <TouchableOpacity onPress={() => setSelectedImage(null)}>
              <Text style={{ color: 'red' }}>✕</Text>
            </TouchableOpacity>

          </View>

        )}

        <View style={styles.inputArea}>

          <TouchableOpacity onPress={pickImage}>
            <Text style={styles.icon}>📎</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={voiceMessage}>
            <Text style={styles.icon}>
              🎙️
            </Text>
          </TouchableOpacity>

          <TextInput
            style={styles.input}
            placeholder="Message TAYUBA AI..."
            placeholderTextColor="#8797B0"
            value={message}
            onChangeText={setMessage}
            multiline
            blurOnSubmit={false}
            returnKeyType="send"
            onSubmitEditing={() => sendMessage()}
          />

          <TouchableOpacity
            style={styles.sendButton}
            onPress={() => sendMessage()}
            disabled={loading}
          >

            <Text style={{ color: 'white', fontSize: 23 }}>
              ➤
            </Text>

          </TouchableOpacity>

        </View>

      </>

    );

  }

  // ==================================
  // HISTORY SCREEN
  // ==================================

  function HistoryScreen() {

    return (

      <ScrollView style={styles.page} keyboardShouldPersistTaps="handled">

        <Text style={styles.heading}>
          Chat History
        </Text>

        <TouchableOpacity
          style={styles.button}
          onPress={newChat}
        >

          <Text style={styles.buttonText}>
            + New Conversation
          </Text>

        </TouchableOpacity>

        {history.map(chat => (

          <TouchableOpacity
            key={chat.id}
            style={styles.card}
            onPress={() => openHistory(chat)}
          >

            <Text style={styles.cardTitle}>
              {chat.title}
            </Text>

            <Text style={styles.subtitle}>
              {new Date(chat.date).toLocaleString()}
            </Text>

          </TouchableOpacity>

        ))}

        <TouchableOpacity
          onPress={() => {

            Alert.alert('Clear history', 'Delete all conversations?', [
              { text: 'Cancel', style: 'cancel' },
              {
                text: 'Delete',
                style: 'destructive',
                onPress: async () => {
                  await AsyncStorage.removeItem(CHAT_KEY);
                  setHistory([]);
                }
              }
            ]);

          }}
        >

          <Text style={{ color: '#FF687D', margin: 20 }}>
            Clear all history
          </Text>

        </TouchableOpacity>

      </ScrollView>

    );

  }

  // ==================================
  // PREMIUM SCREEN
  // ==================================

  function PremiumScreen() {

    return (

      <ScrollView style={styles.page} keyboardShouldPersistTaps="handled">

        <Text style={styles.crown}>
          👑
        </Text>

        <Text style={styles.heading}>
          TAYUBA AI Premium
        </Text>

        <Text style={styles.subtitle}>
          Unlock more possibilities.
        </Text>

        {[
          'Higher AI usage limits',
          'Advanced Gemini models',
          'Voice conversations',
          'Image understanding',
          'Faster AI responses'
        ].map((item, index) => (

          <Text key={index} style={styles.feature}>
            ✓ {item}
          </Text>

        ))}

        <View style={styles.card}>

          <Text style={styles.plan}>
            MONTHLY PLAN
          </Text>

          <Text style={styles.price}>
            ₦1,250 / month
          </Text>

          <TouchableOpacity
            style={styles.button}
            onPress={() =>
              Alert.alert(
                'Monthly Premium',
                'Paystack payment integration is required to activate your subscription.'
              )
            }
          >

            <Text style={styles.buttonText}>
              Choose Monthly
            </Text>

          </TouchableOpacity>

        </View>

        <View style={styles.card}>

          <Text style={styles.plan}>
            YEARLY PLAN
          </Text>

          <Text style={styles.price}>
            ₦10,000 / year
          </Text>

          <TouchableOpacity
            style={styles.button}
            onPress={() =>
              Alert.alert(
                'Yearly Premium',
                'Paystack payment integration is required to activate your subscription.'
              )
            }
          >

            <Text style={styles.buttonText}>
              Choose Yearly
            </Text>

          </TouchableOpacity>

        </View>

        <Text style={styles.subtitle}>
          Payment activation is not connected yet.
        </Text>

      </ScrollView>

    );

  }

  // ==================================
  // PROFILE SCREEN
  // ==================================

  function ProfileScreen() {

    return (

      <ScrollView style={styles.page} keyboardShouldPersistTaps="handled">

        <Text style={styles.heading}>
          Your Profile
        </Text>

        <Text style={styles.subtitle}>
          Manage your account.
        </Text>

        <Text style={styles.field}>
          Display Name
        </Text>

        <TextInput
          style={styles.profileInput}
          value={name}
          onChangeText={setName}
        />

        <Text style={styles.field}>
          Email Address
        </Text>

        <TextInput
          style={styles.profileInput}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
        />

        <Text style={styles.feature}>
          {premium ? '👑 Premium Member' : 'Free Account'}
        </Text>

        <TouchableOpacity
          style={styles.button}
          onPress={saveProfile}
        >

          <Text style={styles.buttonText}>
            Save Profile
          </Text>

        </TouchableOpacity>

      </ScrollView>

    );

  }

  // ==================================
  // MAIN DESIGN
  // ==================================

  return (

    <View
      style={{ flex: 1, backgroundColor: DARK }}
    >

      <View style={styles.overlay}>

        <SafeAreaView style={{ flex: 1 }}>

          <StatusBar barStyle="light-content" />

          <View style={styles.header}>

            <View style={styles.logo}>
              <Text style={styles.logoText}>TA</Text>
            </View>

            <View style={{ flex: 1 }}>

              <Text style={styles.brand}>
                TAYUBA <Text style={{ color: BLUE }}>AI</Text>
              </Text>

              <Text style={styles.subtitle}>
                Your Smart AI Assistant
              </Text>

            </View>

            <TouchableOpacity onPress={() => setTab('Premium')}>
              <Text style={styles.crown}>👑</Text>
            </TouchableOpacity>

          </View>

          <KeyboardAvoidingView
            style={{ flex: 1 }}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
          >

            <View style={{ flex: 1 }}>

              {tab === 'Home' && <HomeScreen />}

              {tab === 'History' && <HistoryScreen />}

              {tab === 'Premium' && <PremiumScreen />}

              {tab === 'Profile' && <ProfileScreen />}

            </View>

          </KeyboardAvoidingView>

          <View style={styles.navigation}>

            {['Home', 'History', 'Premium', 'Profile'].map(item => (

              <TouchableOpacity
                key={item}
                onPress={() => setTab(item)}
                style={{ alignItems: 'center', flex: 1 }}
              >

                <Text style={[
                  styles.navText,
                  tab === item && { color: BLUE }
                ]}>

                  {item === 'Home' ? '⌂' :
                   item === 'History' ? '◷' :
                   item === 'Premium' ? '♛' : '●'}

                </Text>

                <Text style={[
                  styles.navLabel,
                  tab === item && { color: BLUE }
                ]}>
                  {item}
                </Text>

              </TouchableOpacity>

            ))}

          </View>

        </SafeAreaView>

      </View>

    </View>

  );

}

// ==================================
// STYLES
// ==================================

const styles = StyleSheet.create({

  overlay: {
    flex: 1,
    backgroundColor: 'rgba(3,8,20,0.89)'
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderColor: '#1C3557',
    backgroundColor: '#08142B'
  },

  logo: {
    width: 48,
    height: 48,
    borderRadius: 15,
    borderWidth: 2,
    borderColor: BLUE,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12
  },

  logoText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold'
  },

  brand: {
    color: 'white',
    fontSize: 22,
    fontWeight: 'bold'
  },

  subtitle: {
    color: '#A5B5CE',
    fontSize: 13,
    marginTop: 5
  },

  welcome: {
    color: 'white',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 25
  },

  bubble: {
    padding: 14,
    borderRadius: 18,
    marginVertical: 7,
    maxWidth: '88%'
  },

  aiBubble: {
    alignSelf: 'flex-start',
    backgroundColor: '#18263F'
  },

  userBubble: {
    alignSelf: 'flex-end',
    backgroundColor: '#0875E1'
  },

  label: {
    color: '#8CCBFF',
    fontSize: 10,
    fontWeight: 'bold',
    marginBottom: 7
  },

  messageText: {
    color: 'white',
    fontSize: 15,
    lineHeight: 23
  },

  readAloud: {
    color: '#8CCBFF',
    marginTop: 10
  },

  chatImage: {
    width: 180,
    height: 140,
    borderRadius: 10,
    marginBottom: 8
  },

  inputArea: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 10,
    padding: 8,
    borderRadius: 20,
    backgroundColor: '#17263F'
  },

  input: {
    flex: 1,
    color: 'white',
    padding: 10,
    maxHeight: 90
  },

  icon: {
    color: 'white',
    fontSize: 22,
    padding: 7
  },

  sendButton: {
    backgroundColor: BLUE,
    width: 45,
    height: 45,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center'
  },

  preview: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    justifyContent: 'space-around'
  },

  navigation: {
    flexDirection: 'row',
    paddingVertical: 12,
    backgroundColor: '#071329',
    borderTopWidth: 1,
    borderColor: '#1C3557'
  },

  navText: {
    color: '#8294B0',
    fontSize: 23
  },

  navLabel: {
    color: '#8294B0',
    fontSize: 11
  },

  page: {
    flex: 1,
    padding: 20
  },

  heading: {
    color: 'white',
    fontSize: 25,
    fontWeight: 'bold',
    marginBottom: 15
  },

  card: {
    backgroundColor: '#17263F',
    padding: 18,
    borderRadius: 16,
    marginVertical: 10
  },

  cardTitle: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold'
  },

  button: {
    backgroundColor: BLUE,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 15
  },

  buttonText: {
    color: 'white',
    fontWeight: 'bold'
  },

  crown: {
    color: '#FFD34D',
    fontSize: 35,
    textAlign: 'center',
    marginVertical: 10
  },

  feature: {
    color: 'white',
    fontSize: 15,
    marginVertical: 10
  },

  plan: {
    color: '#8CCBFF',
    fontWeight: 'bold'
  },

  price: {
    color: 'white',
    fontSize: 25,
    fontWeight: 'bold',
    marginTop: 10
  },

  field: {
    color: '#8CCBFF',
    marginTop: 20
  },

  profileInput: {
    backgroundColor: '#17263F',
    padding: 13,
    borderRadius: 10,
    color: 'white',
    marginTop: 8
  }

});